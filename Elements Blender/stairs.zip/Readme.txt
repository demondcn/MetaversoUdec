


This Model is Powered By www.3dgurukul.com

The Scene file  is Created in 3DS Max 7.0.

3D Gurukul is dedicated to 3d community.
The Model can be used for non-commercial purpose only.



- www.3dgurukul.com